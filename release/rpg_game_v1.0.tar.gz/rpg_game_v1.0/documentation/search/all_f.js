var searchData=
[
  ['the_20project_0',['Building the Project',['../index.html#build',1,'']]],
  ['traitcount_1',['traitCount',['../structCharacter.html#a7e9185b6b0754ab036c7eca578100e19',1,'Character']]],
  ['traits_2',['traits',['../structCharacter.html#a9be4ffadd5c3c3906b813284f70230b5',1,'Character']]]
];
