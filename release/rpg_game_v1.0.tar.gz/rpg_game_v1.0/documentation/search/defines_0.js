var searchData=
[
  ['color_5fchoice_5fpair_0',['COLOR_CHOICE_PAIR',['../game_8h.html#a6207464641fcf86f3185447384449019',1,'game.h']]],
  ['color_5ferror_5fpair_1',['COLOR_ERROR_PAIR',['../game_8h.html#a1dc9eda9b08dbfbbf62241be323d7be4',1,'game.h']]],
  ['color_5fheader_5fpair_2',['COLOR_HEADER_PAIR',['../game_8h.html#a768505ab92c0157f4ef4f0465f814324',1,'game.h']]],
  ['color_5fnormal_5fpair_3',['COLOR_NORMAL_PAIR',['../game_8h.html#a3e86a3da2f574993a3905e681a5dc4bd',1,'game.h']]],
  ['color_5fstat_5fpair_4',['COLOR_STAT_PAIR',['../game_8h.html#a8b4abc8d401f475b8799ba847622ddd8',1,'game.h']]],
  ['color_5ftitle_5fpair_5',['COLOR_TITLE_PAIR',['../game_8h.html#ac0e208aee31ddd4dbffad4a509f2339c',1,'game.h']]]
];
