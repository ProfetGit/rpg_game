var searchData=
[
  ['id_0',['id',['../structStoryNode.html#a510d6c2cf763212e58526d1148fff2e9',1,'StoryNode']]],
  ['intelligence_1',['intelligence',['../structCharacter.html#ae09e29f93202b927be7ab347f16c8e38',1,'Character']]],
  ['inventory_2',['inventory',['../structGameState.html#a99f42310de9c6d33c52c9a07908c63c5',1,'GameState']]],
  ['inventorycount_3',['inventoryCount',['../structGameState.html#a56efd3cda17ddd73f11450a3fda07187',1,'GameState']]],
  ['isgameover_4',['isGameOver',['../structGameState.html#ac5f4c384c2f354ebcca0e27985d9ab54',1,'GameState']]]
];
