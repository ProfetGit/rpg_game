var searchData=
[
  ['description_0',['description',['../structStoryNode.html#abc5ddf2def8366cce0c37e89ce4a7acd',1,'StoryNode']]]
];
