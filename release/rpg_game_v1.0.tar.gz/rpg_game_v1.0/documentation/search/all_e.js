var searchData=
[
  ['savegame_0',['savegame',['../game_8c.html#ab5cd8bdff3c11389c9665a09744b2953',1,'saveGame(GameState *game):&#160;game.c'],['../game_8h.html#ab5cd8bdff3c11389c9665a09744b2953',1,'saveGame(GameState *game):&#160;game.c']]],
  ['scholar_1',['SCHOLAR',['../character_8h.html#a85302146612e6b98c2845c25d5b0daf7aba648bd03208905f20098edcf351af1a',1,'character.h']]],
  ['started_2',['Getting Started',['../index.html#usage',1,'']]],
  ['story_2ec_3',['story.c',['../story_8c.html',1,'']]],
  ['story_2eh_4',['story.h',['../story_8h.html',1,'']]],
  ['storynode_5',['storynode',['../structStoryNode.html',1,'StoryNode'],['../story_8h.html#a3da4672aadb3db00e6b234350248340e',1,'StoryNode:&#160;story.h']]],
  ['strength_6',['strength',['../structCharacter.html#a7be8b06acf4bcc9c63bf73981675fc6b',1,'Character']]]
];
