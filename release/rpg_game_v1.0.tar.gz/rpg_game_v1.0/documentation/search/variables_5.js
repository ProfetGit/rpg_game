var searchData=
[
  ['player_0',['player',['../structGameState.html#a46b729a72fec2cdab4047aa92c347ff4',1,'GameState']]]
];
