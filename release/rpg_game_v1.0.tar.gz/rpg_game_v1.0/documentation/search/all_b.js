var searchData=
[
  ['name_0',['name',['../structCharacter.html#a5813a445a8e476bcfd6e057f24df0c0b',1,'Character']]],
  ['nextnodes_1',['nextNodes',['../structStoryNode.html#aac268c8a616d644c76a489cda1e7e74f',1,'StoryNode']]],
  ['numchoices_2',['numChoices',['../structStoryNode.html#abd3e5f3e79e2bc7c9af284fa26f8f8d4',1,'StoryNode']]]
];
