var searchData=
[
  ['cleanupdisplay_0',['cleanupdisplay',['../game_8h.html#ae8a62d41a32f0fe6537bc274f536c475',1,'cleanupDisplay(void):&#160;game.c'],['../game_8c.html#ae8a62d41a32f0fe6537bc274f536c475',1,'cleanupDisplay(void):&#160;game.c']]],
  ['cleanupgame_1',['cleanupgame',['../game_8c.html#a7f41b216368a274b57f74a52cdcc1ce8',1,'cleanupGame(GameState *game):&#160;game.c'],['../game_8h.html#a7f41b216368a274b57f74a52cdcc1ce8',1,'cleanupGame(GameState *game):&#160;game.c']]],
  ['cleanupstory_2',['cleanupstory',['../story_8c.html#af3fbd69348260498425447347b5b453a',1,'cleanupStory(StoryNode *root):&#160;story.c'],['../story_8h.html#af3fbd69348260498425447347b5b453a',1,'cleanupStory(StoryNode *root):&#160;story.c']]],
  ['createchapterone_3',['createchapterone',['../story_8c.html#acacc387607cba93bbb3bbbdffeb258ba',1,'createChapterOne(void):&#160;story.c'],['../story_8h.html#acacc387607cba93bbb3bbbdffeb258ba',1,'createChapterOne(void):&#160;story.c']]],
  ['createchapterthree_4',['createchapterthree',['../story_8c.html#aa92169d76837967f1547cc46f683a861',1,'createChapterThree(void):&#160;story.c'],['../story_8h.html#aa92169d76837967f1547cc46f683a861',1,'createChapterThree(void):&#160;story.c']]],
  ['createchaptertwo_5',['createChapterTwo',['../story_8h.html#ac119af8bb00e5d0c09b455fa157d83cb',1,'story.h']]],
  ['createcharacter_6',['createcharacter',['../character_8c.html#a17e2cef081febec875916459517de2e5',1,'createCharacter(void):&#160;character.c'],['../character_8h.html#a17e2cef081febec875916459517de2e5',1,'createCharacter(void):&#160;character.c']]],
  ['createshadowmancerpath_7',['createShadowmancerPath',['../story_8c.html#a2fce7ec0ecb9eab70947ac261de13237',1,'story.c']]],
  ['createsidequests_8',['createSideQuests',['../story_8c.html#a4ac0d11f67a2ba38c4f3fa0f947fe3c3',1,'story.c']]],
  ['createstorynode_9',['createstorynode',['../story_8c.html#a3d9b52e3703b8dc6df1b104ca273e919',1,'createStoryNode(int id, const char *description):&#160;story.c'],['../story_8h.html#a3d9b52e3703b8dc6df1b104ca273e919',1,'createStoryNode(int id, const char *description):&#160;story.c']]]
];
