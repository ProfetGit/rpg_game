var searchData=
[
  ['addchoice_0',['addchoice',['../story_8c.html#a4bade9db191506abf893d7259390c475',1,'addChoice(StoryNode *node, const char *choiceText, StoryNode *nextNode, int reqStr, int reqInt, int reqCha):&#160;story.c'],['../story_8h.html#a4bade9db191506abf893d7259390c475',1,'addChoice(StoryNode *node, const char *choiceText, StoryNode *nextNode, int reqStr, int reqInt, int reqCha):&#160;story.c']]],
  ['addtoinventory_1',['addtoinventory',['../game_8c.html#ae83bff18155483f9ead940e07556b31e',1,'addToInventory(GameState *game, const char *item):&#160;game.c'],['../game_8h.html#ae83bff18155483f9ead940e07556b31e',1,'addToInventory(GameState *game, const char *item):&#160;game.c']]],
  ['addtrait_2',['addtrait',['../character_8c.html#ab720b9982aecd2abee7c92f148873182',1,'addTrait(Character *character, const char *trait):&#160;character.c'],['../character_8h.html#ab720b9982aecd2abee7c92f148873182',1,'addTrait(Character *character, const char *trait):&#160;character.c']]],
  ['architecture_3',['Architecture',['../index.html#arch',1,'']]]
];
