var searchData=
[
  ['character_0',['Character',['../structCharacter.html',1,'']]]
];
