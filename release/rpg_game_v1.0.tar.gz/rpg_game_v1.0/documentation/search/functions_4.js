var searchData=
[
  ['initializecolors_0',['initializecolors',['../game_8c.html#a6fe98bf50d03129bbbde3a96f671f573',1,'initializeColors(void):&#160;game.c'],['../game_8h.html#a6fe98bf50d03129bbbde3a96f671f573',1,'initializeColors(void):&#160;game.c']]],
  ['initializegame_1',['initializegame',['../game_8c.html#ac0997b8549df72a9104d20e06a842298',1,'initializeGame(void):&#160;game.c'],['../game_8h.html#ac0997b8549df72a9104d20e06a842298',1,'initializeGame(void):&#160;game.c']]],
  ['initializestory_2',['initializestory',['../story_8c.html#a536c3f82b64eade434be43fe2490b680',1,'initializeStory(void):&#160;story.c'],['../story_8h.html#a536c3f82b64eade434be43fe2490b680',1,'initializeStory(void):&#160;story.c']]]
];
