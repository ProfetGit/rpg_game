var searchData=
[
  ['updatecharacterstats_0',['updatecharacterstats',['../character_8c.html#a9a92b6d8641f2ba6e58e3c3f05e45788',1,'updateCharacterStats(Character *character, int str, int intel, int cha):&#160;character.c'],['../character_8h.html#a9a92b6d8641f2ba6e58e3c3f05e45788',1,'updateCharacterStats(Character *character, int str, int intel, int cha):&#160;character.c']]],
  ['updategamestate_1',['updategamestate',['../game_8c.html#a3f31bd411bd580548452e31ffecc0d0c',1,'updateGameState(GameState *game):&#160;game.c'],['../game_8h.html#a3f31bd411bd580548452e31ffecc0d0c',1,'updateGameState(GameState *game):&#160;game.c']]]
];
