var searchData=
[
  ['charisma_0',['charisma',['../structCharacter.html#a49139c85576b2193b3656e2626574e7e',1,'Character']]],
  ['choicehistory_1',['choiceHistory',['../structGameState.html#a1d14c3ebac0dd59c32ba2c8904d8bdc7',1,'GameState']]],
  ['choicehistorycount_2',['choiceHistoryCount',['../structGameState.html#a25fa05c6a93ac17f5fb10bd10cfae6c6',1,'GameState']]],
  ['choices_3',['choices',['../structStoryNode.html#a72ef0bbb3cc8124b339b861d6ad2d0e9',1,'StoryNode']]],
  ['class_4',['class',['../structCharacter.html#a51b79e5832dbaf4761076ac159fed521',1,'Character']]],
  ['consequence_5',['consequence',['../structStoryNode.html#a0f673e79d8254a33b957dffb10833431',1,'StoryNode']]],
  ['currentchapter_6',['currentChapter',['../structGameState.html#aff7af760e0c70fec636c982cc12a4cec',1,'GameState']]],
  ['currentscene_7',['currentScene',['../structGameState.html#a37bc8d81791d0a360f257b81b838e404',1,'GameState']]]
];
