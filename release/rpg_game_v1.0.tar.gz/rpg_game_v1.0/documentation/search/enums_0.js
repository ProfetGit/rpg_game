var searchData=
[
  ['characterclass_0',['CharacterClass',['../character_8h.html#a85302146612e6b98c2845c25d5b0daf7',1,'character.h']]]
];
