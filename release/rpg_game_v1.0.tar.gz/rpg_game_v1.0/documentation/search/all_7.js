var searchData=
[
  ['id_0',['id',['../structStoryNode.html#a510d6c2cf763212e58526d1148fff2e9',1,'StoryNode']]],
  ['initializecolors_1',['initializecolors',['../game_8c.html#a6fe98bf50d03129bbbde3a96f671f573',1,'initializeColors(void):&#160;game.c'],['../game_8h.html#a6fe98bf50d03129bbbde3a96f671f573',1,'initializeColors(void):&#160;game.c']]],
  ['initializegame_2',['initializegame',['../game_8c.html#ac0997b8549df72a9104d20e06a842298',1,'initializeGame(void):&#160;game.c'],['../game_8h.html#ac0997b8549df72a9104d20e06a842298',1,'initializeGame(void):&#160;game.c']]],
  ['initializestory_3',['initializestory',['../story_8c.html#a536c3f82b64eade434be43fe2490b680',1,'initializeStory(void):&#160;story.c'],['../story_8h.html#a536c3f82b64eade434be43fe2490b680',1,'initializeStory(void):&#160;story.c']]],
  ['intelligence_4',['intelligence',['../structCharacter.html#ae09e29f93202b927be7ab347f16c8e38',1,'Character']]],
  ['introduction_5',['Introduction',['../index.html#intro',1,'']]],
  ['inventory_6',['inventory',['../structGameState.html#a99f42310de9c6d33c52c9a07908c63c5',1,'GameState']]],
  ['inventorycount_7',['inventoryCount',['../structGameState.html#a56efd3cda17ddd73f11450a3fda07187',1,'GameState']]],
  ['isgameover_8',['isGameOver',['../structGameState.html#ac5f4c384c2f354ebcca0e27985d9ab54',1,'GameState']]]
];
