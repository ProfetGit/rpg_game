var searchData=
[
  ['scholar_0',['SCHOLAR',['../character_8h.html#a85302146612e6b98c2845c25d5b0daf7aba648bd03208905f20098edcf351af1a',1,'character.h']]]
];
