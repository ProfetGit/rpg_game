var searchData=
[
  ['savegame_0',['savegame',['../game_8c.html#ab5cd8bdff3c11389c9665a09744b2953',1,'saveGame(GameState *game):&#160;game.c'],['../game_8h.html#ab5cd8bdff3c11389c9665a09744b2953',1,'saveGame(GameState *game):&#160;game.c']]]
];
