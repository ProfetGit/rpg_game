var searchData=
[
  ['mainpage_2edox_0',['mainpage.dox',['../mainpage_8dox.html',1,'']]],
  ['max_5fchoice_5ftext_1',['max_choice_text',['../game_8h.html#a6e6f3ca18e46f1227c17b10e357c3ed4',1,'MAX_CHOICE_TEXT:&#160;game.h'],['../story_8h.html#a6e6f3ca18e46f1227c17b10e357c3ed4',1,'MAX_CHOICE_TEXT:&#160;story.h']]],
  ['max_5fchoices_2',['max_choices',['../game_8h.html#ab25b10eff9ca6a4b8f3365e617603499',1,'MAX_CHOICES:&#160;game.h'],['../story_8h.html#ab25b10eff9ca6a4b8f3365e617603499',1,'MAX_CHOICES:&#160;story.h']]],
  ['max_5fdescription_5flength_3',['MAX_DESCRIPTION_LENGTH',['../story_8h.html#a7f3a71d25c292b9aa726f7e404aad4d5',1,'story.h']]],
  ['max_5finventory_5fsize_4',['MAX_INVENTORY_SIZE',['../game_8h.html#a428c4db813a3903aa8d062bff5db5df5',1,'game.h']]],
  ['max_5fname_5flength_5',['MAX_NAME_LENGTH',['../character_8h.html#a0c397a708cec89c74029582574516b30',1,'character.h']]],
  ['max_5ftraits_6',['MAX_TRAITS',['../character_8h.html#ab36ffe9087666dd0ff25164fe77c48f1',1,'character.h']]]
];
