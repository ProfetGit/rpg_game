var searchData=
[
  ['story_2ec_0',['story.c',['../story_8c.html',1,'']]],
  ['story_2eh_1',['story.h',['../story_8h.html',1,'']]]
];
