var searchData=
[
  ['reputation_0',['reputation',['../structGameState.html#a1c5385e7c212e94e6b92fd927057cafa',1,'GameState']]],
  ['requirements_1',['requirements',['../structStoryNode.html#afdd9531129d371c0f694b2d5f4a87c14',1,'StoryNode']]]
];
